import { DisplaySlotId, system, world } from "@minecraft/server";
// Crée ou récupère le scoreboard KillCounter et le met dans la Sidebar.
const killCounterObjective = world.scoreboard.getObjective("douarmc:kill_counter")
    ?? world.scoreboard.addObjective("douarmc:kill_counter", "§bKills");
world.scoreboard.setObjectiveAtDisplaySlot(DisplaySlotId.Sidebar, { objective: killCounterObjective });
// Définit le score des joueurs avec une DynamicProperty.
system.runInterval(() => {
    const players = world.getAllPlayers();
    players.forEach((player) => {
        player.setDynamicProperty("douarmc:score_kill_counter_objective", player.getDynamicProperty("douarmc:score_kill_counter_objective") ?? 0);
        killCounterObjective.setScore(player, player.getDynamicProperty("douarmc:score_kill_counter_objective"));
    });
});
// Enlève de l'objectif de Scoreboard les joueurs qui ne sont plus dans le monde.
system.runInterval(() => {
    const killCounterParticipants = killCounterObjective.getParticipants();
    killCounterParticipants.forEach((killCounterParticipant) => {
        try {
            killCounterParticipant.getEntity();
        }
        catch (e) {
            killCounterObjective.removeParticipant(killCounterParticipant);
        }
        ;
    });
});
