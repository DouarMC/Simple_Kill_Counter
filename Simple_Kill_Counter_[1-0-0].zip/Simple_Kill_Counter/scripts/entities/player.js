import { world } from "@minecraft/server";
// Augmente la Propriété dynamique du joueur qui en tue un autre.
world.afterEvents.entityDie.subscribe((eventData) => {
    const { deadEntity: deadPlayer, damageSource } = eventData;
    const damagePlayer = damageSource.damagingEntity;
    if (damagePlayer === undefined)
        return;
    if (damagePlayer.typeId !== "minecraft:player")
        return;
    damagePlayer.setDynamicProperty("douarmc:score_kill_counter_objective", damagePlayer.getDynamicProperty("douarmc:score_kill_counter_objective") + 1);
}, { entityTypes: ["minecraft:player"] });
